<?php
$config['error_prefix'] = '<small> ';
$config['error_suffix'] = '</small>';