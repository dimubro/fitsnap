<div class="container-fluid">
                        <ul class="nav d-lg-flex-column flex-row pt-5">
                            <li class="nav-item my-2 shadow-sm p-1 rounded">
                                <a class="nav-link active fs-6" aria-current="page" href="<?=base_url()?>profile"> Dashboard</a>
                            </li>
                            <li class="nav-item my-2 shadow-sm p-1 rounded">
                                <a class="nav-link fs-6" href="<?=base_url()?>appointments"> Appointments</a>
                            </li>
                            <li class="nav-item my-2 shadow-sm p-1 rounded">
                                <a class="nav-link fs-6" href="#"> Account</a>
                            </li>
                            <li class="nav-item my-2 shadow-sm p-1 rounded">
                                <a class="nav-link fs-6 text-danger" href="<?=base_url()?>log-out"> Logout</a>
                            </li>
                           
                        </ul>
                    </div>