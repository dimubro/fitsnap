<?php $this->load->view('inc/header'); ?>
<div class="breadcrumb-section cart_bread">
    <div class="container">   
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <ul>
                        <li><a href="<?=base_url()?>">home</a></li>
                        <li class="active">Thank you</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>    
</div>
<div class="Checkout_section">
               <div class="container">
                    <div class="row">
                       <div class="col-12 mt-100">
                       	<center >
                       		<h1 class="thank-you-text">Thank You</h1>
                       		<p class="mb-100">Thank you shopping with us!</p>
                       	</center>
                       	</div>
                    </div>
                </div>
</div>
<?php $this->load->view('inc/footer'); ?>