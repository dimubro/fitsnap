<?php include('include/header.php'); ?>
<?php include('include/top_bar.php'); ?>



<div class="container-fluid">
    <div class="row">
        <?php include('include/side_bar.php'); ?>


        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-0">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom page-title-div px-3">
                <h5 class="title_page">Dashboard</h5>
            </div>
            <div class="row mx-3">
                <!-- <div class="col-md-12">
                    <div class="card card_backgroud">
                      <div class="card-header">Header</div>
                      <div class="card-body">Content</div>
                      <div class="card-footer">Footer</div>
                    </div>
                </div> -->
            </div>
        </main>
    </div>
</div>

<?php include('include/page_footer.php'); ?>
<?php include('include/footer.php'); ?>

