<nav class="navbar navbar-light bg-blue">
  <a class="navbar-brand"></a>
  <h6 class="admin_user_name mt-2">Hi!, <?=$this->session->user->FirstName?>  <?=$this->session->user->LastName?></h6>
</nav>
