<?php

//$config['base_url'] = DOMAIN . "admin/";
$config['base_url'] = DOMAIN."/admin";
